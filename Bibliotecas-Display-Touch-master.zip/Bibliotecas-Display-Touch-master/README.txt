Exemplos de uso para o dislay TFT com controlador S6D0154

Para uso com controlador ST7781, altere a linha abaixo, de:

UTFT myGLCD(UNO_24, A2, A1, A3, A4);

para: 

UTFT myGLCD(UNO_26, A2, A1, A3, A4);