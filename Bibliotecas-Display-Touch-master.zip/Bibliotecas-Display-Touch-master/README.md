# Bibliotecas Display Touch 2.4 Arduino

Bibliotecas para utilização com o exemplo do Display TFT Shield do Blog FILIPEFLOP

http://blog.filipeflop.com/arduino/display-touch-arduino-shield.html
